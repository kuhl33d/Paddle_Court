import cv2
from deepface import DeepFace

# Load the Haar Cascade classifier for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Function to detect emotions from a face
def detect_emotions(face):
    # Perform emotion detection using DeepFace
    result = DeepFace.analyze(face, actions=['emotion'], enforce_detection=False)

    # If the result is a list (multiple faces detected), analyze emotions for each face
    if isinstance(result, list):
        emotions = []
        for res in result:
            if 'emotion' in res.keys():
                emotion_dict = res['emotion']
                dominant_emotion = max(emotion_dict, key=emotion_dict.get)
                emotions.append(dominant_emotion)
            else:
                emotions.append("No emotion detected")
        return emotions
    # If the result is a single face
    elif 'emotion' in result.keys():
        emotion_dict = result['emotion']
        dominant_emotion = max(emotion_dict, key=emotion_dict.get)
        return [dominant_emotion]
    else:
        return ["No emotion detected"]

# Capture video from the default camera (0)
video_capture = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()

    # Convert the frame to grayscale for face detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Iterate through detected faces
    for (x, y, w, h) in faces:
        # Extract the face region
        face = frame[y:y+h, x:x+w]

        # Detect emotions in the face region
        detected_emotions = detect_emotions(face)

        # Display the rectangle around the face
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        # Display the detected emotions text above the face rectangle
        for idx, emotion in enumerate(detected_emotions):
            cv2.putText(frame, emotion, (x, y - 20 - idx * 20), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

    # Display the captured frame
    cv2.imshow('Video', frame)

    # Break the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture object and close OpenCV windows
video_capture.release()
cv2.destroyAllWindows()