import cv2
import csv
import numpy as np

def detect_eyes(frame, csv_writer):
    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Use Haarcascades for face and eye detection
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
    
    # Detect faces in the frame
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    
    # Create a heatmap
    heatmap = np.zeros_like(gray, dtype=np.float32)
    
    for (x, y, w, h) in faces:
        roi_gray = gray[y:y+h, x:x+w]
        
        # Detect eyes in the face region
        eyes = eye_cascade.detectMultiScale(roi_gray)
        
        for (ex, ey, ew, eh) in eyes:
            # Update the heatmap in the eye region
            heatmap[y+ey:y+ey+eh, x+ex:x+ex+ew] += 1
            
            # Print and write the eye coordinates to the CSV file
            eye_x, eye_y = x + ex + ew // 2, y + ey + eh // 2
            print(f"Eye Coordinates: x={eye_x}, y={eye_y}")
            
            # Open the CSV file and write the coordinates
            with open('eye_coordinates.csv', mode='a', newline='') as csv_file:
                csv_writer = csv.DictWriter(csv_file, fieldnames=['Eye X', 'Eye Y'])
                csv_writer.writerow({'Eye X': eye_x, 'Eye Y': eye_y})
    
    # Normalize the heatmap
    cv2.normalize(heatmap, heatmap, 0, 255, cv2.NORM_MINMAX)
    heatmap = heatmap.astype(np.uint8)
    
    return frame, heatmap

# Open a connection to the webcam (you can specify the camera index, usually 0 for built-in webcams)
cap = cv2.VideoCapture(0)

while True:
    # Capture frame-by-frame
    ret, frame = cap.read()

    # Perform eye detection and create the heatmap
    result_frame, eye_heatmap = detect_eyes(frame, csv_writer=None)

    # Display the result
    cv2.imshow('Eye Detection and Heatmap', result_frame)
    cv2.imshow('Eye Heatmap', cv2.applyColorMap(eye_heatmap, cv2.COLORMAP_HOT))

    # Break the loop if 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the camera and close all windows
cap.release()
cv2.destroyAllWindows()
